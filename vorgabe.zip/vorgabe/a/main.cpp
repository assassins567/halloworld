#include "systemc.h"
#include "Producer.h"
#include "Consumer.h"

int sc_main(int argc, char* argv[])
{
	// generating the sc_signal
	
	// generating the modules
	

	// connecting modules via signals
	

	// Run the simulation till sc_stop is encountered
	

	return 0;
}

