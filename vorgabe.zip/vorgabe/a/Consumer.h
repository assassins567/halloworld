#include "systemc.h"

#ifndef CONSUMER_H_
#define CONSUMER_H_

SC_MODULE(Consumer){
	//ports
	//local vars	

	SC_CTOR(Consumer){
	//declare method
	//sensitivity	
	}

	void consume()
	{
		//read number
		//print output
		
	}

};

#endif

 

